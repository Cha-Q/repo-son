package com.sg.pasteurisation.Spr_pasteurisation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprPasteurisationApplicationTests {

	@Test
	void contextLoads() {
	}

}

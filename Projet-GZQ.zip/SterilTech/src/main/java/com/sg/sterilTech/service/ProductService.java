package com.sg.sterilTech.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sg.sterilTech.entity.product.Product;
import com.sg.sterilTech.repository.ProductRepository;

@Service
public class ProductService
{

	private ProductRepository productRepo;

	public ProductService(
			ProductRepository productRepo
	)
	{
		this.productRepo = productRepo;
		
	}

//	private void hydrate()
//	{
//		products.add(
//				new Product(
//						1, "Prune", 4, "/img/prunes.jfif", decimalTService.getDtById(
//								1
//						)
//				)
//		);
//		products.add(
//				new Product(
//						2, "Pomme", 3, "/img/pomme.jfif", decimalTService.getDtById(
//								2
//						)
//				)
//		);
//		products.add(
//				new Product(
//						3, "Pamplemouse", 2, "/img/pamplemousse.jfif", decimalTService.getDtById(
//								4
//						)
//				)
//		);
//		products.add(
//				new Product(
//						4, "orange", 4, "/img/orange.jpg", decimalTService.getDtById(
//								2
//						)
//				)
//		);
//		products.add(
//				new Product(
//						5, "Mure", 5, "/img/mures.jpg", decimalTService.getDtById(
//								2
//						)
//				)
//		);
//		products.add(
//				new Product(
//						6, "Groseille", 6, "/img/groseilles.jfif", decimalTService.getDtById(
//								1
//						)
//				)
//		);
//		products.add(
//				new Product(
//						7, "tomate", 4, "/img/tomates.jfif", decimalTService.getDtById(
//								2
//						)
//				)
//		);
//		products.add(
//				new Product(
//						8, "framboise", 3, "/img/framboises.jpg", decimalTService.getDtById(
//								1
//						)
//				)
//		);
//		products.add(
//				new Product(
//						9, "fraise", 5, "/img/fraise.jfif", decimalTService.getDtById(
//								2
//						)
//				)
//		);
//		products.add(
//				new Product(
//						10, "citrone", 2, "/img/citron.jfif", decimalTService.getDtById(
//								4
//						)
//				)
//		);
//
//	}

	public List<Product> showProducts()
	{

		return productRepo.findAll();
	}

	
	public Product getProductByName(
			String product
	)
	{
		return productRepo.findByNameProduct(product); 
	}

	public Product getProductById(
			int idProduct
	)
	{
		return productRepo.findById(idProduct);
	}

	public void addProduct(
			int id, String productName, int ph
	)
	{
		productRepo.save(
				new Product(
						productName, ph
				)
		);
	}
}

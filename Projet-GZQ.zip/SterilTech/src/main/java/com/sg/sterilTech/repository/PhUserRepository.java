package com.sg.sterilTech.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.sg.sterilTech.entity.phUser.PhUser;
import com.sg.sterilTech.entity.user.User;

public interface PhUserRepository extends JpaRepository<PhUser, Integer> {
	public List<PhUser> findByUser(User user);
}

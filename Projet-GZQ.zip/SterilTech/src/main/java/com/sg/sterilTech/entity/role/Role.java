package com.sg.sterilTech.entity.role;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

// role de l utilisateur : admin / lambda 
@Entity(
		name = "role"
)
@Table(
		name = "role"
)
public class Role
{
	@Id
	@GeneratedValue
	@Column(
			name = "id_role"
	)
	int idRole = 0;

	@Column(
			name = "name_role"
	)
	String nameRole = "";

	public int getIdRole()
	{
		return idRole;
	}

	public void setIdRole(
			int idRole
	)
	{
		this.idRole = idRole;
	}

	public String getNameRole()
	{
		return nameRole;
	}

	public void setNameRole(
			String nameRole
	)
	{
		this.nameRole = nameRole;
	}

	public Role(
			int idRole, String nameRole
	)
	{
		super();
		this.idRole = idRole;
		this.nameRole = nameRole;
	}

	public Role()
	{
		super();
	}

	@Override
	public String toString()
	{
		return "Role [idRole=" + idRole + ", nameRole=" + nameRole + "]";
	}

}

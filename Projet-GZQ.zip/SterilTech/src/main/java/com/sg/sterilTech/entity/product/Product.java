package com.sg.sterilTech.entity.product;

import com.sg.sterilTech.entity.decimalTime.DecimalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity(
		name = "product"
)
@Table(
		name = "product"
)
public class Product
{

	@Id
	@GeneratedValue
	private int idProduct;

	@Column(
			name = "name_product"
	)
	private String nameProduct;
	@Column(
			name = "ph_product"
	)
	private double pHProduct;
	@Column(
			name = "url_product"
	)
	private String urlImage;

	@ManyToOne
	@JoinColumn(
			name = "id_dt"
	)
	private DecimalTime dt;

	public Product()
	{
		super();
	}

	public Product(
			int idProduct, String nameProduct, double pHProduct
	)
	{
		super();
		this.idProduct = idProduct;
		this.nameProduct = nameProduct;
		this.pHProduct = pHProduct;
	}
	
	public Product(
			String nameProduct, double pHProduct
	)
	{
		this.nameProduct = nameProduct;
		this.pHProduct = pHProduct;
	}

	public Product(
			int idProduct, String nameProduct, int pHProduct, String urlImage
	)
	{
		super();
		this.idProduct = idProduct;
		this.nameProduct = nameProduct;
		this.pHProduct = pHProduct;
		this.urlImage = urlImage;
	}

	public Product(
			int idProduct, String nameProduct, int pHProduct, String urlImage, DecimalTime dt
	)
	{
		super();
		this.idProduct = idProduct;
		this.nameProduct = nameProduct;
		this.pHProduct = pHProduct;
		this.urlImage = urlImage;
		this.dt = dt;
	}

	public Product(
			int idProduct, String nameProduct, int pHProduct, DecimalTime dt
	)
	{
		super();
		this.idProduct = idProduct;
		this.nameProduct = nameProduct;
		this.pHProduct = pHProduct;
		this.dt = dt;
	}

	public int getIdProduct()
	{
		return idProduct;
	}

	public void setIdProduct(
			int idProduct
	)
	{
		this.idProduct = idProduct;
	}

	public String getNameProduct()
	{
		return nameProduct;
	}

	public void setNameProduct(
			String nameProduct
	)
	{
		this.nameProduct = nameProduct;
	}

	public double getpHProduct()
	{
		return pHProduct;
	}

	public void setpHProduct(
			double d
	)
	{
		this.pHProduct = d;
	}

	public DecimalTime getDt()
	{
		return dt;
	}

	public void setDt(
			DecimalTime dt
	)
	{
		this.dt = dt;
	}

	public String getUrlImage()
	{
		return urlImage;
	}

	public void setUrlImage(
			String urlImage
	)
	{
		this.urlImage = urlImage;
	}

	@Override
	public String toString()
	{
		return "Product [idProduct=" + idProduct + ", nameProduct=" + nameProduct + ", pHProduct=" + pHProduct + ", dt="
				+ dt + "]";
	}

}

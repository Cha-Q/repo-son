package com.sg.sterilTech.controller.signUp;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.sg.sterilTech.service.UserService;

@Controller
@SessionAttributes(
		{"name","id"}
)
public class SignUpController
{

	private UserService userService;

	public SignUpController(
			UserService userService
	)
	{
		this.userService = userService;
	}

	@RequestMapping(
			value = "signUp", method = RequestMethod.GET
	)
	public String signUp(

	)
	{
		return "signUp";
	}

	@RequestMapping(
			value = "signUp", method = RequestMethod.POST
	)
	public String signInUp(
			@RequestParam String name, @RequestParam String firstName, @RequestParam String passwordUser,
			@RequestParam Date date, ModelMap model
	)
	{

		userService.addUser(
				name, firstName, passwordUser, date
		);

		return "redirect:userPage";

	}

}

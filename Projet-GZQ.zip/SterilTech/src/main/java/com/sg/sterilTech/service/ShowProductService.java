package com.sg.sterilTech.service;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.sg.sterilTech.entity.product.Product;
import com.sg.sterilTech.repository.ProductRepository;

@Service
public class ShowProductService {

	
	
	private ProductRepository productRepo;
	private ProductDtService pdtService;
	
	
	
	public ShowProductService(ProductRepository productRepo, ProductDtService pdtService) {

		this.productRepo = productRepo;
		this.pdtService = pdtService;
	}



	public void exec(String ph, String product, ModelMap model) {
		
		Product p = productRepo.findByNameProduct(product);

		
		if (!ph.equalsIgnoreCase("noPh")) {
			p.setpHProduct(Double.parseDouble(ph));
		}

		pdtService.findDt(p);

		model.put("product", p);
		model.put("result", p.getDt().run());

		
	}
	
	
	
}

package com.sg.sterilTech.service;

import org.springframework.stereotype.Service;

import com.sg.sterilTech.entity.phUser.PhUser;
import com.sg.sterilTech.entity.product.Product;
import com.sg.sterilTech.entity.user.User;
import com.sg.sterilTech.repository.PhUserRepository;
import com.sg.sterilTech.repository.ProductRepository;
import com.sg.sterilTech.repository.UserRepository;

@Service
public class SaveProductService {
	
	private UserRepository userRepo;
	private ProductRepository productRepo;
	private PhUserRepository phUserRepo;
	private ProductDtService pdtService;
	
	
	
	public SaveProductService(UserRepository userRepo, ProductRepository productRepo, PhUserRepository phUserRepo,
			ProductDtService pdtService) {
		super();
		this.userRepo = userRepo;
		this.productRepo = productRepo;
		this.phUserRepo = phUserRepo;
		this.pdtService = pdtService;
	}



	public void save(int id, String productName, String phString) {
		
		User user = userRepo.findById(id);
		Product product = productRepo.findByNameProduct(productName);
		Double ph = Double.parseDouble(phString);
		PhUser phUser = new PhUser(user, product, ph);
		phUser.getProduct().setpHProduct(ph);
		
		phUserRepo.save(phUser);
	}
	
}

package com.sg.sterilTech.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sg.sterilTech.entity.category.Category;

@Service
public class CategoryService
{

	private static List<Category> categories = new ArrayList<>();
	private static int idCategory = 0;

	static
	{
		categories.add(
				new Category(
						++idCategory, "fruit"
				)
		);
		categories.add(
				new Category(
						++idCategory, "légume"
				)
		);
	}

	public List<Category> findCategories(

	)
	{
		return categories;
	}
}

package com.sg.sterilTech.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sg.sterilTech.entity.product.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>
{
	public Product findByNameProduct(
			String nameProduct
	);
//
	public Product findById(
			int id
	);
}

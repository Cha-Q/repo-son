package com.sg.sterilTech.service;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.sg.sterilTech.entity.user.User;
import com.sg.sterilTech.repository.UserRepository;

@Service
public class AuthenticationService
{

	private UserRepository userRepo;

	public AuthenticationService(
			UserRepository userRepo
	)
	{
		this.userRepo = userRepo;
	}

	public boolean checkAuth(
			String name, String pwd, ModelMap model
	)
	{
		User checkUser = userRepo.findByFirstName(
				name
		);

		if (checkUser == null)
		{
			return false;
		}

		boolean isName = name.equalsIgnoreCase(
				checkUser.getFirstNameUser()
		);
		boolean isPwd = pwd.equalsIgnoreCase(
				checkUser.getPasswordUser()
		);
		
		if(isName && isPwd) {
			model.put("name", checkUser.getFirstNameUser());
			model.put("id", checkUser.getIdUser());
		}

		return isName && isPwd;
	}
	
}
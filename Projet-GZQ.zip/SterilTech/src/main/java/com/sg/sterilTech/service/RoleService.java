package com.sg.sterilTech.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sg.sterilTech.entity.role.Role;

@Service
public class RoleService
{

	private static List<Role> roles = new ArrayList<>();
	private static int roleCount = 0;

	static
	{
		roles.add(
				new Role(
						++roleCount, "Admin"
				)
		);
		roles.add(
				new Role(
						++roleCount, "User"
				)
		);
	}

	public List<Role> showRoles()
	{
		return roles;
	}

	public void addRole(
			int id, String role
	)
	{

	}
}

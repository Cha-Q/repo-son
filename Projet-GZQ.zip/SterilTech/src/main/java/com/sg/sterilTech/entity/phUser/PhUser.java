package com.sg.sterilTech.entity.phUser;

import java.time.LocalDate;

import com.sg.sterilTech.entity.product.Product;

import com.sg.sterilTech.entity.user.User;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity(name = "ph_user")
@Table(name = "ph_user")
public class PhUser {
	@Id
	@GeneratedValue
	@Column(name = "id_ph_user")
	private int idUser;

	@ManyToOne
	@JoinColumn(name = "id_user")
	private User user;
	@ManyToOne
	@JoinColumn(name = "id_product")
	private Product product;

	@Column(name = "ph")
	private double ph;

	@Column(name = "date")
	private LocalDate date = LocalDate.now();

	public PhUser() {

	}

	public PhUser(int idUser, User user, Product product, double ph) {
		super();
		this.idUser = idUser;
		this.user = user;
		this.product = product;
		this.ph = ph;
	}
	public PhUser(User user, Product product, double ph) {

		this.user = user;
		this.product = product;
		this.ph = ph;
	}

	public int getIdUser() {
		return idUser;
	}

	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Product getProduct() {
		return product;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public double getPh() {
		return ph;
	}

	public void setPh(double ph) {
		this.ph = ph;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "PhUser [idUser=" + idUser + ", user=" + user + ", product=" + product + ", ph=" + ph + "]";
	}

	public void doSmthg() {
		product.setpHProduct(ph);
	}

}

package com.sg.sterilTech.controller.login;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


import com.sg.sterilTech.service.AuthenticationService;

@Controller
@SessionAttributes(
		{"name", "id"}
)
public class LoginController
{

	private AuthenticationService auth;
	

	public LoginController(
			AuthenticationService auth
	)
	{
		this.auth = auth;
		
	}

	@RequestMapping(
			value = "connexion", method = RequestMethod.GET
	)
	public String login(
			ModelMap model
	)
	{
		if (model.getAttribute(
				"name"
		) != null)
		{
			config(
					model
			);
			return "redirect:myPage";
		}
		
		return "login";
	}

	@RequestMapping(
			value = "connexion", method = RequestMethod.POST
	)
	public String logged(
			@RequestParam String name, @RequestParam String pwd, ModelMap model
	)
	{

		if (auth.checkAuth(
				name, pwd, model
		))
		{
			
			model.put(
					"name", name
			);
			config(
					model
			);
			return "redirect:myPage";
		}

		model.put(
				"err", "Nom ou mot de passe incorrect veuillez les saisir à nouveau !"
		);

		return "login";
	}

	public void config(
			ModelMap model
	)
	{
		Map<String, String> links = new HashMap<>();
		links.put(
				"", (String) model.getAttribute(
						"name"
				)
		);
		links.put(
				"disconnect", "log out"
		);
		model.put(
				"link", links
		);

	}

}

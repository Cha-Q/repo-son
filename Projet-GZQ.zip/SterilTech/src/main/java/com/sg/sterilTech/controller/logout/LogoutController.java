package com.sg.sterilTech.controller.logout;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class LogoutController
{
	@RequestMapping(
			value = "disconnect"
	)
	public String disconnect(
			ModelMap model, HttpSession session
	)
	{
		session.removeAttribute(
				"name"
		);
		session.removeAttribute(
				"id"
		);

		return "redirect:Accueil";
	}
}

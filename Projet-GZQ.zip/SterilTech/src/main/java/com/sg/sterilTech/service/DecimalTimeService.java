
package com.sg.sterilTech.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sg.sterilTech.entity.decimalTime.DecimalTime;

@Service
public class DecimalTimeService
{

	private static List<DecimalTime> decimalTimes = new ArrayList<>();
	private static int dtCount = 0;

	static
	{
		System.out.println(
				"hello"
		);
		decimalTimes.add(
				new DecimalTime(
						++dtCount, 121, 0.21, "Clostridium Botulinum"
				)
		);

		decimalTimes.add(
				new DecimalTime(
						++dtCount, 111, 2.21, "Clostridium Botulinum"
				)
		);
		decimalTimes.add(
				new DecimalTime(
						++dtCount, 131.1, 0.021, "Clostridium Botulinum"
				)
		);
		decimalTimes.add(
				new DecimalTime(
						++dtCount, 115, 0.84, "Clostridium Botulinum"
				)
		);
		decimalTimes.add(
				new DecimalTime(
						++dtCount, 80, 120, "Clostridium Botulinum"
				)
		);
		decimalTimes.add(
				new DecimalTime(
						++dtCount, 93.13, 12, "Clostridium Botulinum"
				)
		);

	}

	public List<DecimalTime> findDT(

	)
	{

		return decimalTimes;
	}

	public DecimalTime getDtById(
			int idDt
	)
	{

		for (DecimalTime dt : decimalTimes)
		{
			if (dt.getIdDT() == idDt)
			{
				return dt;
			}
		}
		return null;
	}

}
package com.sg.sterilTech.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.sg.sterilTech.entity.user.User;

//L'annotation Service permet de spécfier à notre spring boot que c'est un bean qu'il va devoir prendre en compte
@Service
public class UserService
{

	private static List<User> users = new ArrayList<>();

	private static int userCount = 0;

	@SuppressWarnings(
		"deprecation"
	)
	static Date date = new Date(
			2024, 8, 26
	);

	static
	{

		users.add(
				new User(
						++userCount, "Sigoillot", "Gaëlle", "mdp", date
				)
		);
		users.add(
				new User(
						++userCount, "Rahimi", "Zainab", "mdp", date
				)
		);
		users.add(
				new User(
						++userCount, "Chassaing", "Quentin", "mdp", date
				)
		);

	}

	public List<User> findUsers(

	)
	{
		return users;
	}

	public User findUsersByFirstName(
			String firstName
	)
	{
		for (User u : users)
		{
			if (u.getFirstNameUser().equalsIgnoreCase(
					firstName
			))
			{
				return u;
			}
		}
		return null;
	}

	public String findUsersByPwd(
			String pwd
	)
	{
		for (User u : users)
		{
			if (u.getPasswordUser().equalsIgnoreCase(
					pwd
			))
			{
				return u.getPasswordUser();
			}
		}
		return null;
	}

//
	public void addUser(
			String name, String firstName, String passwordUser, Date date
	)
	{
		users.add(
				new User(
						++userCount, name, firstName, passwordUser, date
				)
		);

		System.out.println(
				users
		);
	}
}

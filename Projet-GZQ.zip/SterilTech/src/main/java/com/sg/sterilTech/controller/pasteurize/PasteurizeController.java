package com.sg.sterilTech.controller.pasteurize;

import java.util.Map;
import java.util.TreeMap;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


import com.sg.sterilTech.repository.ProductRepository;
import com.sg.sterilTech.service.SaveProductService;
import com.sg.sterilTech.service.ShowProductService;

@Controller
@SessionAttributes({"name", "id"})
public class PasteurizeController {
	
	private ProductRepository productRepo;
	private ShowProductService showProductService;
	private SaveProductService saveProductService;


	public PasteurizeController(ProductRepository productRepo, ShowProductService showProductService, SaveProductService saveProductService

	) {
		this.productRepo = productRepo;
		this.showProductService = showProductService;
		this.saveProductService = saveProductService;
	}
	

	@RequestMapping(value = "pasteurize", method = RequestMethod.GET)
	public String pasteurizePage(ModelMap model) {


		if (model.getAttribute("name") == null) {
			return "redirect:myPage";
		}

		config(model);

		return "calc";
	}

	@RequestMapping(value = "pasteurize", method = RequestMethod.POST)
	public String pasteurizeCalc(@RequestParam String product, @RequestParam String ph, ModelMap model) {
		config(model);

		if (!product.equalsIgnoreCase("nc")) {
			
			int id = (int) model.getAttribute("id"); 
			
			showProductService.exec(ph, product, model);
			saveProductService.save(id, product, ph);
			
			return "calcInfo";
		}

		model.put("err", "Veuillez selectionner un aliment ");
		return "calc";
	}



	public void config(ModelMap model) 
	{

		Map<String, String> links = new TreeMap<>();

		links.put("connexion", (String) model.getAttribute("name"));

		links.put("disconnect", "Log out");

		model.put("link", links);

		Sort sort = Sort.by(Sort.Direction.ASC, "nameProduct");

		model.addAttribute("products", productRepo.findAll(sort));
	}
}
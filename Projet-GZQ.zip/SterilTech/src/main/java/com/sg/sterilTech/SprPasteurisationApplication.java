package com.sg.sterilTech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprPasteurisationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprPasteurisationApplication.class, args);
	}
	
}

package com.sg.sterilTech.controller.userPage;



import java.util.Map;
import java.util.TreeMap;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.SessionAttributes;



import com.sg.sterilTech.service.ShowPersonalProductService;


@Controller
@SessionAttributes({"name", "id"})
public class UserPageController {
	
	private ShowPersonalProductService showPprod;
	
	
	public UserPageController(ShowPersonalProductService showPprod) {
		super();
		this.showPprod = showPprod;
	}


	@RequestMapping(value = "myPage", method = RequestMethod.GET)
	public String personnalPage(ModelMap model) {

//		Empêche un utilisateur non connecté de rejoindre la page des utilisateurs
		if (model.getAttribute("name") == null) {
			
			return "redirect:login";
		}

		config(model);
		int id = (int) model.getAttribute("id");
		model.put("products", showPprod.showSmthg(id));
		
	
		return "userPage";
	}


	public void config(ModelMap model) 
	{

		Map<String, String> links = new TreeMap<>();

		links.put("connexion", (String) model.getAttribute("name"));

		links.put("disconnect", "Log out");

		model.put("link", links);

		
	}

}

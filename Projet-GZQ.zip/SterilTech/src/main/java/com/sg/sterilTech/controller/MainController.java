package com.sg.sterilTech.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController
{

	@RequestMapping(
			value = ""
	)
	public String index(
			ModelMap model
	)
	{

		init(
				model
		);

		return "index";

	}

	@RequestMapping(
			value = "Accueil"
	)
	public String accueil(
			ModelMap model
	)
	{
		init(
				model
		);
		
		return "index";

	}

	public void init(
			ModelMap model
	)
	{
		Map<String, String> btns = new HashMap<>();
		btns.put(
				"connexion", "connexion"
		);
		btns.put(
				"sign-Up", "Inscription"
		);
		model.put(
				"buttons", btns
		);
	}

}

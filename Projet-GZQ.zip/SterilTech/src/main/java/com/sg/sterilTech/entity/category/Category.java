package com.sg.sterilTech.entity.category;

public class Category
{
	// trois categories aliments : acide / moyennement acide / peu ou pas acide
	// a faire : une enumeration!!
	int idCategory = 0;
	String nameCategory = "";

	public int getIdCategory()
	{
		return idCategory;
	}

	public void setIdCategory(
			int idCategory
	)
	{
		this.idCategory = idCategory;
	}

	public String getNameCategory()
	{
		return nameCategory;
	}

	public void setNameCategory(
			String nameCategory
	)
	{
		this.nameCategory = nameCategory;
	}

	public Category(
			int idCategory, String nameCategory
	)
	{
		super();
		this.idCategory = idCategory;
		this.nameCategory = nameCategory;
	}

	public Category()
	{
		super();
	}

	@Override
	public String toString()
	{
		return "Category [idCategory=" + idCategory + ", nameCategory=" + nameCategory + "]";
	}

}

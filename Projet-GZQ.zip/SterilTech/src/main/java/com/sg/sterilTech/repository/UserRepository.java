package com.sg.sterilTech.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sg.sterilTech.entity.user.User;

public interface UserRepository extends JpaRepository<User, Integer>
{
	public User findByFirstName(
			String firstName
	);
	public User findById(
			int id
	);
}

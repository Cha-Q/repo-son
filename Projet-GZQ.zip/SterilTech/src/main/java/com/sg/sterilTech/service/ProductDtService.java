package com.sg.sterilTech.service;

import org.springframework.stereotype.Service;

import com.sg.sterilTech.entity.product.Product;
import com.sg.sterilTech.repository.DecimalTimeRepository;
import com.sg.sterilTech.repository.ProductRepository;

@Service
public class ProductDtService
{

	
	private DecimalTimeRepository decimalTimeRepo;

	public ProductDtService(
			DecimalTimeRepository decimalTimeRepo
	)
	{
	
		this.decimalTimeRepo = decimalTimeRepo;

	}

	public void run(
			Product p
	)
	{
		if (p.getDt() == null)
		{
			p.setDt(
					decimalTimeRepo.findById(
							1
					)
			);
		}

	}

	public void findDt(
			Product p
	)
	{
		double productPh = p.getpHProduct();
		if (productPh < 4)
		{
			p.setDt(
					decimalTimeRepo.findById(
							5
					)
			);
			return;
		}

		if (productPh >= 4 && productPh < 5)
		{
			p.setDt(
					decimalTimeRepo.findById(
							2
					)
			);
			return;
		}

		if (productPh >= 5)
		{
			p.setDt(
					decimalTimeRepo.findById(
							1
					)
			);
			return;
		}
	}

}

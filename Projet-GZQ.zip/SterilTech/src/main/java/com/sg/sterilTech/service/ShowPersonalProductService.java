package com.sg.sterilTech.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.sg.sterilTech.entity.phUser.PhUser;
import com.sg.sterilTech.entity.user.User;
import com.sg.sterilTech.repository.PhUserRepository;
import com.sg.sterilTech.repository.UserRepository;

@Service
public class ShowPersonalProductService {
	
	
	private PhUserRepository phUserRepo;
	private UserRepository userRepo;

	public ShowPersonalProductService(PhUserRepository phUserRepo, UserRepository userRepo) {
		super();
		this.phUserRepo = phUserRepo;
		this.userRepo = userRepo;
	}
	
	public List<PhUser> showSmthg(int id){
		User user = userRepo.findById(id);
		return phUserRepo.findByUser(user);
	}
	
	
}

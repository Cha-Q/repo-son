package com.sg.sterilTech.entity.decimalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity(
		name = "decimal_time"
)
@Table(
		name = "decimalTime"
)
public class DecimalTime
{

//	Attributs de classe (attributs dans la table)
	@Id
	@GeneratedValue
	@Column(
			name = "id_dt"
	)
	private int idDT;
	@Column(
			name = "temperature"
	)
	private double temperature; // température de référence
	@Column(
			name = "time"
	)
	private double time; // durée
	@Column(
			name = "micro_orga"
	)
	private String microOrga; // micro-organisme pour la valeur de DT

//	Attributs liés au calcul dans l'application
	@Transient
	private double sterilTime;
	@Transient
	private double microOrgaCoeff;

	public DecimalTime()
	{
		super();
	}

	public DecimalTime(
			int idDT, double temperature, double time, String microOrga
	)
	{
		super();
		this.idDT = idDT;
		this.temperature = temperature;
		this.time = time;
		this.microOrga = microOrga;
	}

	public int getIdDT()
	{
		return idDT;
	}

	public void setIdDT(
			int idDT
	)
	{
		this.idDT = idDT;
	}

	public double getTemperature()
	{
		return temperature;
	}

	public void setTemperature(
			double temperature
	)
	{
		this.temperature = temperature;
	}

	public double getTime()
	{
		return time;
	}

	public void setTime(
			double time
	)
	{
		this.time = time;
	}

	public String getMicroOrga()
	{
		return microOrga;
	}

	public void setMicroOrga(
			String microOrga
	)
	{
		this.microOrga = microOrga;
	}

	public double getSterilTime()
	{
		return sterilTime;
	}

	public double getMicroOrgaCoeff()
	{
		return microOrgaCoeff;
	}

	public void setSterilTime(
			double sterilTime
	)
	{
		this.sterilTime = sterilTime;
	}

	public void setMicroOrgaCoeff(
			double microOrgaCoeff
	)
	{
		this.microOrgaCoeff = microOrgaCoeff;
	}

	@Override
	public String toString()
	{
		return "DecimalTime [idDT=" + idDT + ", temperature=" + temperature + ", time=" + time + ", microOrga="
				+ microOrga + "]";
	}

//	Methods

	public double run()
	{
		this.sterilTime = this.time * orgaCalc(
				0.0, 0.0
		);
		return this.sterilTime;

	}

	public double orgaCalc(
			double n, double N
	)
	{
		double calcLog = Math.log(
				n / N
		);

		return 12;
	}

}

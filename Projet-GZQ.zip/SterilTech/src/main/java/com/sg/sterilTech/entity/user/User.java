package com.sg.sterilTech.entity.user;

import java.util.Date;

import com.sg.sterilTech.entity.role.Role;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity(
		name = "user"
)
@Table(
		name = "user"
)
public class User
{
	@Id
	@GeneratedValue
	@Column(
			name = "id_user"
	)
	private int idUser = 0;
	
	@Column(
			name = "name"
	)
	private String nameUser = "";
	
	@Column(
			name = "firstname"
	)
	private String firstName = "";
	
	@Column(
			name = "password"
	)
	private String passwordUser = "";
	
	@ManyToOne
	@JoinColumn(
			name = "id_role"
	)
	private Role role;

	@Transient
	private Date date;

	public User()
	{
	}

	public User(
			int idUser, String nameUser, String firstName, String passwordUser, Date date
	)
	{
		super();
		this.idUser = idUser;
		this.nameUser = nameUser;
		this.firstName = firstName;
		this.passwordUser = passwordUser;
		this.date = date;
	}

	public int getIdUser()
	{
		return idUser;
	}

	public void setIdUser(
			int idUser
	)
	{
		this.idUser = idUser;
	}

	public String getNameUser()
	{
		return nameUser;
	}

	public void setNameUser(
			String nameUser
	)
	{
		this.nameUser = nameUser;
	}

	public String getFirstNameUser()
	{
		return firstName;
	}

	public void setFirstNameUser(
			String firstName
	)
	{
		this.firstName = firstName;
	}

	public String getPasswordUser()
	{
		return passwordUser;
	}

	public void setPasswordUser(
			String passwordUser
	)
	{
		this.passwordUser = passwordUser;
	}

	public Date getDate()
	{
		return date;
	}

	public void setDate(
			Date date
	)
	{
		this.date = date;
	}

	@Override
	public String toString()
	{
		return "User [idUser=" + idUser + ", nameUser=" + nameUser + ", firstNameUSer=" + firstName + ", passwordUser="
				+ passwordUser + ", date=" + date + "]";
	}

}

package com.sg.sterilTech.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sg.sterilTech.entity.decimalTime.DecimalTime;

public interface DecimalTimeRepository extends JpaRepository<DecimalTime, Integer>
{

	public DecimalTime findByTemperature(
			double temperature
	);

	public DecimalTime findById(
			int id
	);
}

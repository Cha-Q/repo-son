function collapse(){
	let btn = document.querySelector("#btn")
	let navbar =  document.querySelector("#navbarNav")
	if(btn != null && navbar != null){
		btn.addEventListener('click', (e) => {

				navbar.classList.toggle('collapse');
			})
	}
}
	
collapse();
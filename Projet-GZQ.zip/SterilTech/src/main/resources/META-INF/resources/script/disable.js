function disable() {
  let check = document.getElementById("checking");
  let phInput = document.querySelector("#ph");
  let truthy = true;
  phInput.setAttribute("disabled", true)
  check.setAttribute("checked", true)
  
  check.addEventListener('click', (e) => {
	 
	if(check.getAttribute('checked')){
		check.removeAttribute("checked")
		phInput.removeAttribute("disabled")
		
		
	} else {
		phInput.setAttribute("disabled", true)
		check.setAttribute("checked", true)
	}
  })
}
disable();